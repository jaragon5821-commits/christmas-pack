# Chop's clean join: Call Your Horse load message silenced
