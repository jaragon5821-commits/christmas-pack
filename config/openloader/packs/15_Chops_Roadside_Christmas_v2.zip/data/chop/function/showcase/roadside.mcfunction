# Chop roadside Christmas builds showcase. Stand on superflat ground, face north, run /function chop:showcase/roadside
place template chop:roadside/medium/sleigh_rest_stop ~-60 ~-1 ~-13
place template chop:roadside/medium/gingerbread_hut ~-46 ~-1 ~-13
place template chop:roadside/small/roadside_tree ~-34 ~-1 ~-11
place template chop:roadside/small/market_stall ~-24 ~-1 ~-10
place template chop:roadside/small/wayside_shrine ~-14 ~-1 ~-9
place template chop:roadside/medium/ice_fishing_hut ~-6 ~-2 ~-13
place template chop:roadside/medium/woodcutter_lean_to ~8 ~-1 ~-11
place template chop:roadside/small/mail_post ~20 ~-1 ~-8
place template chop:roadside/small/snowman_pair ~28 ~-1 ~-8
place template chop:roadside/small/cider_cart ~38 ~-1 ~-9
place template chop:roadside/medium/hot_spring_shelter ~48 ~-2 ~-14
place template chop:roadside/medium/boardwalk_lookout ~62 ~-1 ~-13
tellraw @s {"text":"Placed 12 Christmas roadside builds to the north","color":"green"}
