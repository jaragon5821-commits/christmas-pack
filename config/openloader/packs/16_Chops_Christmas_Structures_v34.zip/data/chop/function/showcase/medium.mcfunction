# Stand on superflat ground, face north, run /function chop:showcase/medium (two rows). On superflat they sit 1-2 blocks high on their dirt skirt (the world floor stops it going deeper).
place template chop:medium/toy_shop ~-60 ~-1 ~-39
place template chop:medium/bakery ~-24 ~-1 ~-39
place template chop:medium/candle_maker ~12 ~-1 ~-39
place template chop:medium/post_office ~48 ~-1 ~-39
place template chop:medium/holly_inn ~84 ~-1 ~-41
place template chop:medium/snowy_chapel ~126 ~-1 ~-43
place template chop:medium/snow_windmill ~150 ~-1 ~-36
place template chop:medium/star_observatory ~-60 ~-1 ~-68
place template chop:medium/winter_greenhouse ~-36 ~-1 ~-66
place template chop:medium/watchtower_ruin ~-12 ~-1 ~-66
place template chop:medium/gingerbread_manor ~10 ~-1 ~-70
place template chop:medium/snow_globe ~36 ~-1 ~-70
place template chop:medium/reindeer_carousel ~62 ~-1 ~-68
tellraw @s {"text":"Placed 13 medium Christmas structures in two rows to the north","color":"green"}
