# Stand on superflat ground, face north, run /function chop:showcase/small (two rows). On superflat they sit 1-2 blocks high on their dirt skirt (the world floor stops it going deeper).
place template chop:small/snowman_family ~-70 ~-1 ~-27
place template chop:small/gift_pile ~-50 ~-1 ~-28
place template chop:small/sled_rest ~-32 ~-1 ~-29
place template chop:small/skating_pond ~-12 ~-4 ~-30
place template chop:small/frozen_well ~9 ~-1 ~-26
place template chop:small/carolers_gazebo ~24 ~-1 ~-28
place template chop:small/elf_workshop ~41 ~-1 ~-28
place template chop:small/candy_cane_grove ~58 ~-1 ~-27
place template chop:small/sleigh_wreck ~75 ~-1 ~-27
place template chop:small/gingerbread_ruin ~93 ~-1 ~-27
place template chop:small/igloo_camp ~110 ~-1 ~-29
place template chop:small/cocoa_stand ~129 ~-1 ~-25
place template chop:small/fallen_bauble ~-70 ~-1 ~-54
place template chop:small/fallen_star ~-53 ~-1 ~-59
place template chop:small/snow_fort ~-32 ~-1 ~-56
place template chop:small/cookie_oven ~-10 ~-1 ~-53
place template chop:small/ice_sculpture_garden ~7 ~-1 ~-54
place template chop:small/nutcracker_gate ~26 ~-1 ~-54
place template chop:small/toy_train ~49 ~-1 ~-53
place template chop:small/wreath_arch ~73 ~-1 ~-50
place template chop:small/reindeer_stable ~92 ~-1 ~-54
place template chop:small/frozen_campsite ~111 ~-1 ~-55
place template chop:small/candle_circle ~131 ~-1 ~-54
place template chop:small/bell_tower_small ~148 ~-1 ~-52
tellraw @s {"text":"Placed 24 small Christmas structures in two rows to the north","color":"green"}
