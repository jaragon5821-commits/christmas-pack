# Stand on superflat ground, face north, run /function chop:showcase/houses. On superflat they sit 1-2 blocks high on their dirt skirt (the world floor stops it going deeper).
place template chop:starter_houses/old_cottage_red ~-55 ~-1 ~-26
place template chop:starter_houses/old_cottage_green ~-20 ~-1 ~-26
place template chop:starter_houses/old_brick_house ~15 ~-1 ~-26
place template chop:starter_houses/old_timber_house ~52 ~-1 ~-28
place template chop:starter_houses/old_blue_house ~89 ~-1 ~-26
place template chop:starter_houses/old_stone_cottage ~124 ~-1 ~-26
tellraw @s {"text":"Placed 6 old Christmas starter houses to the north","color":"green"}
