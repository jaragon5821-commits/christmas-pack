# Stand on superflat ground, face north, run /function chop:showcase/large (three rows, walk north to see them all). On superflat they sit 1-2 blocks high on their dirt skirt (the world floor stops it going deeper).
place template chop:large/town_hall ~-75 ~-1 ~-47
place template chop:large/santas_workshop ~-36 ~-1 ~-47
place template chop:large/ice_castle ~5 ~-1 ~-54
place template chop:large/christmas_market ~48 ~-1 ~-50
place template chop:large/train_station ~-75 ~-1 ~-89
place template chop:large/ski_lodge ~-34 ~-1 ~-90
place template chop:large/reindeer_stables ~1 ~-1 ~-91
place template chop:large/elf_village ~42 ~-1 ~-96
place template chop:large/frozen_ship ~-75 ~-1 ~-130
place template chop:large/candy_castle ~-30 ~-1 ~-140
place template chop:large/ice_cathedral_ruin ~11 ~-1 ~-143
place template chop:large/skating_rink ~48 ~-1 ~-148
tellraw @s {"text":"Placed 12 medium-large Christmas structures (incl. the skating rink) in three rows to the north","color":"green"}
