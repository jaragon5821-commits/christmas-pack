# Superflat OK. Face north, run /function chop:showcase/end_statues (two rows)
place template chop:end_statue/dream_santa ~-100 ~-4 ~-37
place template chop:end_statue/dream_reindeer ~-66 ~-4 ~-48
place template chop:end_statue/dream_snowman ~-26 ~-4 ~-40
place template chop:end_statue/dream_angel ~11 ~-4 ~-37
place template chop:end_statue/dream_nutcracker ~45 ~-4 ~-37
place template chop:end_statue/dream_gingerbread ~82 ~-4 ~-40
place template chop:end_statue/dream_bell ~-100 ~-4 ~-93
place template chop:end_statue/dream_star ~-73 ~-4 ~-90
place template chop:end_statue/the_sleeper ~-45 ~-4 ~-94
place template chop:end_statue/world_in_his_hand ~-7 ~-4 ~-80
place template chop:end_statue/the_first_carol ~21 ~-4 ~-81
place template chop:end_statue/wrapped_hunger ~46 ~-4 ~-80
