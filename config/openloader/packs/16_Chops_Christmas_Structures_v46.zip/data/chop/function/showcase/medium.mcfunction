# Stand on superflat ground, face north, run /function chop:showcase/medium (two rows). On superflat they sit 1-2 blocks high on their dirt skirt (the world floor stops it going deeper).
place template chop:medium/toy_shop ~-60 ~-1 ~-37
place template chop:medium/bakery ~-26 ~-1 ~-37
place template chop:medium/candle_maker ~8 ~-1 ~-37
place template chop:medium/post_office ~42 ~-1 ~-37
place template chop:medium/holly_inn ~76 ~-1 ~-39
place template chop:medium/snowy_chapel ~116 ~-1 ~-41
place template chop:medium/snow_windmill ~138 ~-1 ~-34
place template chop:medium/star_observatory ~-60 ~-1 ~-66
place template chop:medium/winter_greenhouse ~-38 ~-1 ~-64
place template chop:medium/watchtower_ruin ~-16 ~-1 ~-64
place template chop:medium/gingerbread_manor ~4 ~-1 ~-68
place template chop:medium/snow_globe ~28 ~-1 ~-68
place template chop:medium/reindeer_carousel ~52 ~-1 ~-66
tellraw @s {"text":"Placed 13 medium Christmas structures in two rows to the north","color":"green"}
