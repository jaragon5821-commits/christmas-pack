# Superflat OK. Face north, run /function chop:showcase/nether_small
place template chop:nether_small/gnome_tool_cache ~-40 ~-1 ~-23
place template chop:nether_small/soul_lantern_wayshrine ~-24 ~-1 ~-21
place template chop:nether_small/charred_stocking ~-10 ~-1 ~-21
place template chop:nether_small/abandoned_coal_cart ~4 ~-1 ~-21
place template chop:nether_small/burnt_candy_canes ~22 ~-1 ~-23
place template chop:nether_small/melted_snowman ~38 ~-1 ~-23
place template chop:nether_small/piglin_present_stack ~54 ~-1 ~-21
place template chop:nether_small/ember_chimney_pot ~68 ~-1 ~-21
