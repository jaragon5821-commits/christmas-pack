# Superflat OK. Face north, run /function chop:showcase/mega (two megastructures side by side to the north)
place template chop:mega/lost_workshop ~-75 ~-1 ~-68
place template chop:citadel/naughty_citadel_grand ~6 ~-14 ~-131
tellraw @s {"text":"Placed Santa's Lost Workshop and Claws' Naughty Citadel to the north","color":"green"}
