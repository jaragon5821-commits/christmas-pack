# Superflat OK. Face north, run /function chop:showcase/end_small
place template chop:end_small/star_shard ~-50 ~-1 ~-25
place template chop:end_small/purpur_gift_crate ~-32 ~-1 ~-23
place template chop:end_small/chorus_candy_cane ~-16 ~-1 ~-23
place template chop:end_small/end_rod_lamp_post ~0 ~-1 ~-21
place template chop:end_small/reindeer_constellation_stone ~14 ~-1 ~-21
place template chop:end_small/shulker_bauble_tree ~30 ~-1 ~-23
place template chop:end_small/snow_globe_fragment ~46 ~-1 ~-25
place template chop:end_small/ender_pearl_bell_post ~64 ~-1 ~-21
place template chop:end_small/drifting_present ~78 ~-1 ~-21
place template chop:end_small/elf_telescope_stand ~92 ~-1 ~-21
place template chop:end_small/frozen_enderman_caroler ~108 ~-1 ~-21
place template chop:end_small/purpur_bench_lantern ~122 ~-1 ~-21
