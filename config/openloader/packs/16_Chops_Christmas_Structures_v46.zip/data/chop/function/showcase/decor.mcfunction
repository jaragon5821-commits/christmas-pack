# Superflat OK (sits ~2 high there). Face north, run /function chop:showcase/decor (three rows)
place template chop:xmas_decor/giant_stocking ~-110 ~-4 ~-40
place template chop:xmas_decor/teddy_bear ~-69 ~-4 ~-41
place template chop:xmas_decor/rocking_horse_tipped ~-36 ~-4 ~-43
place template chop:xmas_decor/toy_drum ~12 ~-4 ~-41
place template chop:xmas_decor/jingle_bells ~45 ~-4 ~-35
place template chop:xmas_decor/peppermints ~74 ~-4 ~-38
place template chop:xmas_decor/cocoa_mug ~-110 ~-4 ~-77
place template chop:xmas_decor/cookies_and_milk ~-77 ~-4 ~-79
place template chop:xmas_decor/santa_hat_dropped ~-45 ~-4 ~-75
place template chop:xmas_decor/poinsettia ~-17 ~-4 ~-81
place template chop:xmas_decor/giant_pinecone ~14 ~-4 ~-77
place template chop:xmas_decor/snowflake_crystal ~44 ~-4 ~-71
place template chop:xmas_decor/yule_log ~-110 ~-4 ~-115
place template chop:xmas_decor/lost_mitten ~-78 ~-4 ~-118
place template chop:xmas_decor/stuck_santa_chimney ~-46 ~-4 ~-113
place template chop:xmas_decor/north_pole_signpost ~-15 ~-4 ~-111
place template chop:xmas_decor/santa_mailbox ~8 ~-4 ~-114
place template chop:xmas_decor/wreath_lamp_posts ~32 ~-4 ~-105
tellraw @s {"text":"Placed 18 Christmas decor pieces in three rows to the north","color":"green"}
