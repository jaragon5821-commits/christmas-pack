# Superflat (Josh 23:48): stand on the grass, face north, run /function chop:showcase/dungeons. Each dungeon is pasted with its BOTTOM on the world floor and rises up; fly up to see the surface camp on top.
place template chop:dungeon/krampus_lair ~-60 ~-4 ~-49
place template chop:dungeon/snow_queen_crypt ~-25 ~-4 ~-49
place template chop:dungeon/naughty_coal_mine ~8 ~-4 ~-43
place template chop:dungeon/gingerbread_catacombs ~39 ~-4 ~-43
place template chop:dungeon/buried_sleigh_vault ~70 ~-4 ~-41
place template chop:dungeon/ornament_vault ~101 ~-4 ~-39
place template chop:dungeon/frozen_elf_tomb ~132 ~-4 ~-41
tellraw @s {"text":"Placed 7 Christmas dungeons in a row to the north (walk down their stairwells)","color":"green"}
