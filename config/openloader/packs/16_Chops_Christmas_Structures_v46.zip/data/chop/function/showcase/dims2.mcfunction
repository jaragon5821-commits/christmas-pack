# Superflat OK (they float). Face north, run /function chop:showcase/dims2
place template chop:nether_bastion/burnt_gingerbread_bastion ~-80 ~ ~-57
place template chop:nether_hearth/krampus_hearth ~-31 ~ ~-45
place template chop:end_tree/void_christmas_tree ~12 ~ ~-49
place template chop:end_sleigh/phantom_sleigh ~53 ~ ~-63
