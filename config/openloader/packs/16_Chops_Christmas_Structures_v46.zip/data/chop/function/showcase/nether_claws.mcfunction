# Superflat OK. Face north, run /function chop:showcase/nether_claws
place template chop:nether_claws/coal_gnome_pit ~-90 ~-8 ~-45
place template chop:nether_claws/claws_cradle ~-51 ~-8 ~-37
place template chop:nether_claws/gnome_wrapping_works ~-20 ~-8 ~-33
place template chop:nether_claws/naughty_list_spire ~15 ~-8 ~-31
place template chop:nether_claws/thorned_coal_tree ~40 ~-8 ~-31
place template chop:nether_claws/gnome_warren ~65 ~-8 ~-35
