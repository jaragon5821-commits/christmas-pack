# Superflat OK (sits ~2 high there). Face north, run /function chop:showcase/items (two rows)
place template chop:candy_cane/candy_cane_straight ~-100 ~-4 ~-32
place template chop:candy_cane/candy_cane_leaning ~-75 ~-4 ~-38
place template chop:candy_cane/candy_cane_steep ~-49 ~-4 ~-40
place template chop:candy_cane/candy_cane_pair ~-12 ~-4 ~-45
place template chop:candy_cane/candy_cane_hook_buried ~28 ~-4 ~-42
place template chop:candy_cane/candy_cane_massive ~50 ~-4 ~-43
place template chop:candy_cane/candy_cane_massive_fallen ~91 ~-4 ~-49
place template chop:xmas_item/ornament_red_cracked ~-100 ~-4 ~-100
place template chop:xmas_item/ornament_blue_cracked ~-66 ~-4 ~-102
place template chop:xmas_item/ornament_green_cracked ~-30 ~-4 ~-98
place template chop:xmas_item/ornament_purple_cracked ~3 ~-4 ~-100
place template chop:xmas_item/string_lights_buried ~37 ~-4 ~-88
place template chop:xmas_item/string_lights_coil ~79 ~-4 ~-93
place template chop:xmas_item/giant_present_open ~105 ~-4 ~-104
tellraw @s {"text":"Placed 14 giant Christmas items: 7 candy canes, then ornaments, lights and a present","color":"green"}
