# Superflat OK (they float: the Nether mine is a carved block of rock). Face north, run /function chop:showcase/dims
place template chop:nether/nether_coal_mines ~-60 ~ ~-71
place template chop:end/starfall_observatory ~-1 ~ ~-61
tellraw @s {"text":"Placed the Naughty Coal Mines (Nether) and the Starfall Observatory (End) to the north","color":"green"}
