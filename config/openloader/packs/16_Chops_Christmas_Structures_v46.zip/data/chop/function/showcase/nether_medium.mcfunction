# Superflat OK. Face north, run /function chop:showcase/nether_medium
place template chop:nether_medium/coal_gnome_burrow ~-70 ~-1 ~-31
place template chop:nether_medium/soul_lantern_market ~-45 ~-1 ~-29
place template chop:nether_medium/cinder_candy_stand ~-14 ~-1 ~-27
place template chop:nether_medium/krampus_woodshed ~7 ~-1 ~-27
place template chop:nether_medium/warped_wreath_shrine ~30 ~-1 ~-27
place template chop:nether_medium/ash_chapel ~53 ~-1 ~-35
place template chop:nether_medium/burnt_post_office ~76 ~-1 ~-29
