# Superflat OK (the cathedral is a buried block, the galleon sits on its ice). Face north, run /function chop:showcase/jack_frost
place template chop:jack_frost/frost_spire/frost_spire ~-150 ~-1 ~-49
place template chop:jack_frost/jack_frost_workshop/jack_frost_workshop ~-109 ~-1 ~-39
place template chop:jack_frost/frozen_waterfall_grotto/frozen_waterfall_grotto ~-76 ~-1 ~-51
place template chop:jack_frost/icicle_cathedral/icicle_cathedral ~-31 ~-4 ~-67
place template chop:jack_frost/frostbitten_village/frostbitten_village ~18 ~-1 ~-67
place template chop:jack_frost/rime_gardens/rime_gardens ~81 ~-1 ~-55
place template chop:jack_frost/snowflake_monoliths/snowflake_monoliths ~128 ~-1 ~-63
place template chop:jack_frost/breath_of_winter/breath_of_winter ~183 ~-1 ~-33
place template chop:jack_frost/frozen_galleon/frozen_galleon ~208 ~-4 ~-68
