# Stand on superflat ground, face north, run /function chop:showcase/large (three rows, walk north to see them all). On superflat they sit 1-2 blocks high on their dirt skirt (the world floor stops it going deeper).
place template chop:large/town_hall ~-75 ~-1 ~-45
place template chop:large/santas_workshop ~-38 ~-1 ~-45
place template chop:large/ice_castle ~1 ~-1 ~-52
place template chop:large/christmas_market ~42 ~-1 ~-48
place template chop:large/train_station ~-75 ~-1 ~-87
place template chop:large/ski_lodge ~-36 ~-1 ~-88
place template chop:large/reindeer_stables ~-3 ~-1 ~-89
place template chop:large/elf_village ~36 ~-1 ~-94
place template chop:large/frozen_ship ~-75 ~-1 ~-128
place template chop:large/candy_castle ~-32 ~-1 ~-138
place template chop:large/ice_cathedral_ruin ~7 ~-1 ~-141
place template chop:large/skating_rink ~42 ~-1 ~-146
tellraw @s {"text":"Placed 12 medium-large Christmas structures (incl. the skating rink) in three rows to the north","color":"green"}
