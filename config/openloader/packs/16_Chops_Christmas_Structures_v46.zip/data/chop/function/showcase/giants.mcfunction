# Superflat OK. HUGE: fly up and back. Face north, run /function chop:showcase/giants (one row, ~600 blocks wide)
place template chop:giant/crooked_santa_colossus/crooked_santa_colossus ~-300 ~-4 ~-104
place template chop:giant/frozen_titan_elf/frozen_titan_elf ~-216 ~-4 ~-124
place template chop:giant/last_reindeer_arch/last_reindeer_arch ~-131 ~-4 ~-98
place template chop:giant/claws_hand/claws_hand ~-27 ~-4 ~-131
place template chop:giant/ornament_world_tree/ornament_world_tree ~88 ~-4 ~-127
place template chop:giant/sleeping_snow_giant/sleeping_snow_giant ~184 ~-4 ~-148
place template chop:giant/nutcracker_sentinel/nutcracker_sentinel ~387 ~-4 ~-90
