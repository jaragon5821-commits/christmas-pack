# Superflat OK. Face north, run /function chop:showcase/end_medium
place template chop:end_medium/chorus_candy_garden ~-70 ~-1 ~-31
place template chop:end_medium/silent_night_chapel ~-43 ~-1 ~-35
place template chop:end_medium/star_map_pavilion ~-20 ~-1 ~-31
place template chop:end_medium/elf_void_outpost ~5 ~-1 ~-27
place template chop:end_medium/gift_ship_wreck ~26 ~-1 ~-27
place template chop:end_medium/starlight_forge_hut ~55 ~-1 ~-29
place template chop:end_medium/purpur_post_office ~78 ~-1 ~-29
