# Superflat OK. Face north, run /function chop:showcase/arenas (Clinker Forge, Claws' Citadel; the Toymaster hall is under the Naughty Citadel in showcase/mega)
place template chop:nether_boss/clinker_forge ~-60 ~-1 ~-68
place template chop:end_boss/claws_citadel ~3 ~-1 ~-107
