# Superflat OK. Face north, run /function chop:showcase/nether_mimic
place template chop:nether_mimic/lava_snowman ~-45 ~-1 ~-27
place template chop:nether_mimic/basalt_tree ~-27 ~-1 ~-23
place template chop:nether_mimic/bone_reindeer ~-11 ~-1 ~-19
place template chop:nether_mimic/magma_present_pile ~5 ~-1 ~-21
place template chop:nether_mimic/quartz_icing_house ~19 ~-1 ~-23
place template chop:nether_mimic/soul_candle_trio ~35 ~-1 ~-21
