# Stand on superflat ground, face north, run /function chop:showcase/houses. On superflat they sit 1-2 blocks high on their dirt skirt (the world floor stops it going deeper).
place template chop:starter_houses/old_cottage_red ~-55 ~-1 ~-24
place template chop:starter_houses/old_cottage_green ~-22 ~-1 ~-24
place template chop:starter_houses/old_brick_house ~11 ~-1 ~-24
place template chop:starter_houses/old_timber_house ~46 ~-1 ~-26
place template chop:starter_houses/old_blue_house ~81 ~-1 ~-24
place template chop:starter_houses/old_stone_cottage ~114 ~-1 ~-24
place template chop:starter_houses/family_home_cream ~147 ~-1 ~-22
place template chop:starter_houses/family_home_brick ~174 ~-1 ~-22
place template chop:starter_houses/family_home_timber ~201 ~-1 ~-22
place template chop:starter_houses/family_home_stone ~228 ~-1 ~-22
place template chop:starter_houses/family_home_mint ~255 ~-1 ~-22
place template chop:starter_houses/family_home_red ~282 ~-1 ~-22
tellraw @s {"text":"Placed the Christmas starter houses + family homes to the north","color":"green"}
