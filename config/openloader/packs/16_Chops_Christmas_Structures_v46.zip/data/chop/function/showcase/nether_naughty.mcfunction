# Superflat OK. Face north, run /function chop:showcase/nether_naughty
place template chop:nether_naughty/naughty_list ~-11 ~-1 ~-30
