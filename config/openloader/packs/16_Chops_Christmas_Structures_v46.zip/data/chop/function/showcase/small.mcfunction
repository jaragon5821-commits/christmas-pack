# Stand on superflat ground, face north, run /function chop:showcase/small (two rows). On superflat they sit 1-2 blocks high on their dirt skirt (the world floor stops it going deeper).
place template chop:small/snowman_family ~-70 ~-1 ~-25
place template chop:small/gift_pile ~-52 ~-1 ~-26
place template chop:small/sled_rest ~-36 ~-1 ~-27
place template chop:small/skating_pond ~-18 ~-4 ~-28
place template chop:small/frozen_well ~1 ~-1 ~-24
place template chop:small/carolers_gazebo ~14 ~-1 ~-26
place template chop:small/elf_workshop ~29 ~-1 ~-32
place template chop:small/candy_cane_grove ~54 ~-1 ~-25
place template chop:small/sleigh_wreck ~69 ~-1 ~-25
place template chop:small/gingerbread_ruin ~85 ~-1 ~-25
place template chop:small/igloo_camp ~100 ~-1 ~-27
place template chop:small/cocoa_stand ~117 ~-1 ~-23
place template chop:small/fallen_bauble ~-70 ~-1 ~-52
place template chop:small/fallen_star ~-55 ~-1 ~-57
place template chop:small/snow_fort ~-36 ~-1 ~-54
place template chop:small/cookie_oven ~-16 ~-1 ~-51
place template chop:small/ice_sculpture_garden ~-1 ~-1 ~-52
place template chop:small/nutcracker_gate ~16 ~-1 ~-52
place template chop:small/toy_train ~37 ~-1 ~-51
place template chop:small/wreath_arch ~59 ~-1 ~-48
place template chop:small/reindeer_stable ~76 ~-1 ~-52
place template chop:small/frozen_campsite ~93 ~-1 ~-53
place template chop:small/candle_circle ~111 ~-1 ~-52
place template chop:small/bell_tower_small ~126 ~-1 ~-50
tellraw @s {"text":"Placed 24 small Christmas structures in two rows to the north","color":"green"}
