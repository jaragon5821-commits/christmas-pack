# Superflat OK. Face north, run /function chop:showcase/events (Claws outpost s1-s3, then spire s1-s3)
place template chop:event/claws_outpost_s1 ~-50 ~-1 ~-27
place template chop:event/claws_outpost_s2 ~-31 ~-1 ~-27
place template chop:event/claws_outpost_s3 ~-12 ~-1 ~-27
place template chop:event/claws_spire_s1 ~7 ~-1 ~-23
place template chop:event/claws_spire_s2 ~22 ~-1 ~-23
place template chop:event/claws_spire_s3 ~37 ~-1 ~-23
