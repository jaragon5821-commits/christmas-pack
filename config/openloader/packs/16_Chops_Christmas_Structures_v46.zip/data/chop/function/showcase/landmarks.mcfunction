# Run in a NORMAL world on open flat ground (they reach ~25 blocks down and up to 70 up). Face north, run /function chop:showcase/landmarks
place template chop:landmark/grinning_snowman ~-90 ~-16 ~-49
place template chop:landmark/claws_snow_globe ~-47 ~-16 ~-53
place template chop:landmark/gnome_ornament ~0 ~-16 ~-51
place template chop:landmark/ransacked_tree ~45 ~-16 ~-65
tellraw @s {"text":"Placed 4 Festivity landmarks in a row to the north: snowman, snow globe, ornament, ransacked tree","color":"green"}
