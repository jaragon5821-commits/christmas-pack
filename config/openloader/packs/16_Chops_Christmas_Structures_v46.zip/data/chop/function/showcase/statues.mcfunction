# Stand on superflat ground, face north, run /function chop:showcase/statues (two rows). Superflat: the dirt cone is cut short (world floor), so they sit ~2 blocks high here.
place template chop:statue/santa_copper ~-70 ~-4 ~-35
place template chop:statue/reindeer_head ~-36 ~-4 ~-38
place template chop:statue/snowman_fallen ~-5 ~-4 ~-38
place template chop:statue/angel_broken_wing ~32 ~-4 ~-34
place template chop:statue/nutcracker_leaning ~65 ~-4 ~-35
place template chop:statue/gingerbread_giant ~102 ~-4 ~-38
place template chop:statue/cracked_bell ~-70 ~-4 ~-91
place template chop:statue/star_pillar ~-43 ~-4 ~-88
place template chop:statue/sour_elf_watcher ~-15 ~-4 ~-77
place template chop:statue/coal_stocking ~13 ~-4 ~-77
place template chop:statue/marching_four ~46 ~-4 ~-75
place template chop:statue/cursed_star_crater ~81 ~-4 ~-82
tellraw @s {"text":"Placed 12 aged Christmas statues in two rows to the north","color":"green"}
