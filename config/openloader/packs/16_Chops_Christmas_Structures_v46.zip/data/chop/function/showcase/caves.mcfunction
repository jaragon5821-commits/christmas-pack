# Superflat OK (chambers float). Face north, run /function chop:showcase/caves
place template chop:cave/candy_cane_cave ~-40 ~ ~-39
place template chop:cave/ornament_cave ~-3 ~ ~-41
