# Superflat OK. Face north, run /function chop:showcase/nether_statues (two rows)
place template chop:nether_statue/claws_effigy ~-100 ~-4 ~-37
place template chop:nether_statue/hellhorn_reindeer ~-66 ~-4 ~-41
place template chop:nether_statue/cinder_snowman_fallen ~-35 ~-4 ~-40
place template chop:nether_statue/fallen_angel ~2 ~-4 ~-36
place template chop:nether_statue/grinning_nutcracker ~35 ~-4 ~-37
place template chop:nether_statue/burnt_gingerbread_giant ~74 ~-4 ~-40
place template chop:nether_statue/soul_bell ~-100 ~-4 ~-93
place template chop:nether_statue/inverted_star ~-73 ~-4 ~-90
place template chop:nether_statue/claws_hatching ~-45 ~-4 ~-89
place template chop:nether_statue/coal_gnome_idol ~-8 ~-4 ~-83
place template chop:nether_statue/krampus_captain ~18 ~-4 ~-78
place template chop:nether_statue/sour_elf_choir ~49 ~-4 ~-77
