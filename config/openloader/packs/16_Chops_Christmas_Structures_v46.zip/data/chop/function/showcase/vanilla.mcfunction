# Superflat OK. Face north, run /function chop:showcase/vanilla (Igloo Village row; then vanilla structures with the overlays)
place template chop:vanilla/igloo_village/igloo_village ~-24 ~-11 ~-65
place structure minecraft:swamp_hut ~-200 ~ ~-160
place structure minecraft:pillager_outpost ~-110 ~ ~-160
place structure minecraft:mansion ~-20 ~ ~-160
place structure minecraft:ruined_portal ~70 ~ ~-160
place structure minecraft:trail_ruins ~160 ~ ~-160
place structure minecraft:trial_chambers ~250 ~ ~-160
