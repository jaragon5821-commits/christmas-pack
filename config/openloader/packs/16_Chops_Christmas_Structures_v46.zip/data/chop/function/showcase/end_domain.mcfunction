# Superflat OK. Face north, run /function chop:showcase/end_domain
place template chop:end_domain/claws_domain_rift ~-10 ~-7 ~-25
