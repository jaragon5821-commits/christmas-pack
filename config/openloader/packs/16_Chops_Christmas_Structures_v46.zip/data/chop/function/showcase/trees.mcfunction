# Stand on superflat ground, face north, run /function chop:showcase/trees
place template chop:xmas_trees/tree_07_natural ~-70 ~-3 ~-13
place template chop:xmas_trees/tree_08_classic ~-60 ~-3 ~-13
place template chop:xmas_trees/tree_09_frost ~-50 ~-3 ~-15
place template chop:xmas_trees/tree_10_candy ~-38 ~-3 ~-15
place template chop:xmas_trees/tree_11_natural ~-26 ~-3 ~-15
place template chop:xmas_trees/tree_12_rainbow ~-14 ~-3 ~-15
place template chop:xmas_trees/tree_13_gold ~-2 ~-3 ~-17
place template chop:xmas_trees/tree_14_classic ~12 ~-3 ~-17
place template chop:xmas_trees/tree_15_natural ~26 ~-3 ~-17
place template chop:xmas_trees/tree_16_frost ~40 ~-3 ~-17
place template chop:xmas_trees/tree_17_candy ~54 ~-3 ~-19
place template chop:xmas_trees/tree_18_classic ~70 ~-3 ~-20
place template chop:xmas_trees/tree_19_natural ~87 ~-3 ~-20
place template chop:xmas_trees/tree_20_rainbow ~104 ~-3 ~-20
place template chop:xmas_trees/tree_20_gold ~121 ~-3 ~-22
place template chop:xmas_tree_xl/xl_christmas_tree ~-15 ~-4 ~-61
tellraw @s {"text":"Placed 15 Christmas trees + the XL tree to the north","color":"green"}
