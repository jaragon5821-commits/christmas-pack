# Superflat OK. Face north, run /function chop:showcase/cave_decor (needs ~12 free blocks up)
fill ~-18 ~-1 ~-62 ~-1 ~-1 ~-46 minecraft:dripstone_block
fill ~-18 ~8 ~-62 ~-1 ~8 ~-46 minecraft:dripstone_block
fill ~1 ~-1 ~-62 ~18 ~-1 ~-46 minecraft:moss_block
fill ~1 ~8 ~-62 ~18 ~8 ~-46 minecraft:deepslate
place feature chop:candy_cane_stalagmite_short ~-16 ~ ~-60
place feature chop:candy_cane_stalagmite_tall ~-12 ~ ~-56
place feature chop:candy_cane_stalagmite_short ~-8 ~ ~-61
place feature chop:candy_cane_stalagmite_tall ~-4 ~ ~-52
place feature chop:candy_cane_stalagmite_short ~-15 ~ ~-50
place feature chop:candy_cane_stalagmite_tall ~-10 ~ ~-48
place feature chop:candy_cane_stalagmite_short ~-6 ~ ~-57
place feature chop:candy_cane_stalagmite_tall ~-3 ~ ~-47
place feature chop:candy_cane_stalactite ~-14 ~7 ~-58
place feature chop:candy_cane_stalactite ~-9 ~7 ~-53
place feature chop:candy_cane_stalactite ~-5 ~7 ~-49
place feature chop:candy_cane_stalactite ~-17 ~7 ~-47
place feature chop:candy_cane_stalactite ~-2 ~7 ~-60
place feature chop:hanging_bauble ~3 ~7 ~-59
place feature chop:hanging_bauble ~3 ~7 ~-56
place feature chop:hanging_bauble ~3 ~7 ~-53
place feature chop:hanging_bauble ~3 ~7 ~-50
place feature chop:hanging_bauble ~3 ~7 ~-47
place feature chop:hanging_bauble ~6 ~7 ~-60
place feature chop:hanging_bauble ~6 ~7 ~-57
place feature chop:hanging_bauble ~6 ~7 ~-54
place feature chop:hanging_bauble ~6 ~7 ~-51
place feature chop:hanging_bauble ~6 ~7 ~-48
place feature chop:hanging_bauble ~9 ~7 ~-59
place feature chop:hanging_bauble ~9 ~7 ~-56
place feature chop:hanging_bauble ~9 ~7 ~-53
place feature chop:hanging_bauble ~9 ~7 ~-50
place feature chop:hanging_bauble ~9 ~7 ~-47
place feature chop:hanging_bauble ~12 ~7 ~-60
place feature chop:hanging_bauble ~12 ~7 ~-57
place feature chop:hanging_bauble ~12 ~7 ~-54
place feature chop:hanging_bauble ~12 ~7 ~-51
place feature chop:hanging_bauble ~12 ~7 ~-48
place feature chop:hanging_bauble ~15 ~7 ~-59
place feature chop:hanging_bauble ~15 ~7 ~-56
place feature chop:hanging_bauble ~15 ~7 ~-53
place feature chop:hanging_bauble ~15 ~7 ~-50
place feature chop:hanging_bauble ~15 ~7 ~-47
