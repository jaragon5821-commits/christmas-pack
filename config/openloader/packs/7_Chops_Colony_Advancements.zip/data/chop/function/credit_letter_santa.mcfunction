festivity credit @s letter_santa
advancement revoke @s only chop:letter_to_santa
