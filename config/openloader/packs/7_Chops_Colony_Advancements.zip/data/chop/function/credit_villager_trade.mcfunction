festivity credit @s villager_trade
advancement revoke @s only chop:villager_trade
