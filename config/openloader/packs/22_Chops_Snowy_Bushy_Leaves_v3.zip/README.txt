Chop's Snowy Bushy Leaves v0.2 (prototype). Geometry = Motschen's Better Leaves (MIT) bushy models, untinted;
textures = our repaint of Better Leaves' 32x32 leaf shapes: winter colours, snow on the upper fringe, snow cap on top.
Covers vanilla + Biomes O' Plenty + Oh The Biomes We've Gone (every leaf Better Leaves supports there).
Textures live in the chopsnow namespace, so the Christmas packs' files are never touched. Load ABOVE them.